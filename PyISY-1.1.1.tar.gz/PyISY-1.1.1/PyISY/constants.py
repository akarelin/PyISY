import datetime

_change2update_interval = 0.5
_empty_time = datetime.datetime(year=1, month=1, day=1)
