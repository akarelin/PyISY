PyISY

Python Library for the ISY Controller

This library allows for easy interaction with ISY nodes, programs, program,
climate module, and network module. This class also allows for functions to be
assigned as handlers when ISY parameters are changed. ISY parameters can be
monitored automatically as changes are reported from the device.

For more information, visit the Automicus website.

AUTHOR: Automicus (Ryan Kraus)
DATE: 4/2014
EMAIL: automicus@gmail.com
WEBSITE: http://automic.us/portfolio/pyisy

